<?php return array (
  'ar.accounts-recievable' => 'App\\Http\\Livewire\\Ar\\AccountsRecievable',
  'bm.allocation' => 'App\\Http\\Livewire\\Bm\\Allocation',
  'bm.history' => 'App\\Http\\Livewire\\Bm\\History',
  'bm.request-list' => 'App\\Http\\Livewire\\Bm\\RequestList',
  'collections.collections' => 'App\\Http\\Livewire\\Collections\\Collections',
  'disbursement.disburse-requests' => 'App\\Http\\Livewire\\Disbursement\\DisburseRequests',
  'general.chart-of-accounts' => 'App\\Http\\Livewire\\General\\ChartOfAccounts',
  'sidebar' => 'App\\Http\\Livewire\\Sidebar',
);