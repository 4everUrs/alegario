var Turbolinks = require("turbolinks")
Turbolinks.start()