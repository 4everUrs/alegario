// require('./bootstrap');
require('./main');

// import Alpine from 'alpinejs';

// window.Alpine = Alpine;

// Alpine.start();


