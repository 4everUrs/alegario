<div>
    <?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'id',
    'model',
    'maxWidth' => '2xl',
    ]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'id',
    'model',
    'maxWidth' => '2xl',
    ]); ?>
<?php foreach (array_filter(([
    'id',
    'model',
    'maxWidth' => '2xl',
    ]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
    <div <?php echo e($attributes->merge(['class' => 'modal fade'])); ?> id="<?php echo e($id); ?>" tabindex="-1" style="display: none;" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e($title); ?></h5> <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php echo e($body); ?>

                </div>
                <div class="modal-footer"> 
                    <button type="button" class="btn btn-secondary"
                        data-bs-dismiss="modal">Close
                    </button> 
                    <button wire:click="<?php echo e($model); ?>" type="button" class="btn btn-primary">Save
                    </button>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\romel\Desktop\alergiocurehms\resources\views/components/breeze-modal.blade.php ENDPATH**/ ?>