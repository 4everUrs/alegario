<div>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 font-weight-bold">
            <?php echo e(__('Request List')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-body p-3">
           <table class="table-sm datatable">
                <thead >
                    <th class="text-center align-middle">No.</th>
                    <th class="text-center align-middle">Department</th>
                    <th class="text-center align-middle">Requestor</th>
                    <th class="text-center align-middle">Description</th>
                    <th class="text-center align-middle">Proposed Amount</th>
                    <th class="text-center align-middle">Approved Amount</th>
                    <th class="text-center align-middle">Date Request</th>
                    <th class="text-center align-middle">Date Approved</th>
                    <th class="text-center align-middle">Attachment</th>
                    <th class="text-center align-middle">Status</th>
                    <th class="text-center align-middle">Remarks</th>
                    <th class="text-center align-middle">Action</th>
                </thead>
                <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center align-middle"><?php echo e($request->id); ?></td>
                        <td class="text-center align-middle"><?php echo e($request->department); ?></td>
                        <td class="text-center align-middle"><?php echo e($request->requestor); ?></td>
                        <td class="text-center align-middle"><?php echo e($request->description); ?></td>
                        <td class="text-center align-middle"><?php echo '₱ ' . number_format($request->amount, 2); ?></td>
                        <?php if(!empty($request->approved_amount)): ?>
                            <td class="text-center align-middle"><?php echo '₱ ' . number_format($request->approved_amount, 2); ?></td>
                        <?php else: ?>
                            <td class="text-center align-middle">N/A</td>
                        <?php endif; ?>
                        <td class="text-center align-middle"><?php echo Carbon\Carbon::parse($request->created_at)->toFormattedDateString()?></td>
                        <?php if(!empty($request->date_approved)): ?>
                            <td class="text-center align-middle"><?php echo e($request->date_approved); ?></td>
                        <?php else: ?>
                            <td class="text-center align-middle">--/--/----</td>
                        <?php endif; ?>
                        <?php if(!empty($request->file_name)): ?>
                            <td class="text-center align-middle"><?php echo e($request->file_name); ?></td>
                        <?php else: ?>
                            <td class="text-center align-middle">N/A</td>
                        <?php endif; ?>
                        <td class="text-center align-middle"><?php echo e($request->status); ?></td>
                        <td class="text-center align-middle"><?php echo e($request->remarks); ?></td>
                        <td class="text-center align-middle">
                            <?php if($request->status == 'Pending'): ?>
                                <button wire:click="approveRequest(<?php echo e($request->id); ?>)" class="btn btn-sm btn-primary">Approve</button>
                                <button wire:click="denyRequestId(<?php echo e($request->id); ?>)" data-bs-toggle="modal" data-bs-target="#remarkModal"
                                    class="btn btn-sm btn-danger">Deny</button>
                            <?php else: ?>
                                <button wire:click="approveRequest(<?php echo e($request->id); ?>)" class="btn btn-sm btn-secondary" disabled>Approved</button>
                                <button disabled wire:click="denyRequestId(<?php echo e($request->id); ?>)" data-bs-toggle="modal" data-bs-target="#remarkModal"
                                    class="btn btn-sm btn-secondary">Denied</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </table>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breeze-modal','data' => ['id' => 'remarkModal','model' => 'denyRequest','wire:ignore.self' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breeze-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'remarkModal','model' => 'denyRequest','wire:ignore.self' => true]); ?>
         <?php $__env->slot('title', null, []); ?> 
            Remarks
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('body', null, []); ?> 
            <div class="form-group">
                <label>Remarks</label>
                <textarea rows="5" class="form-control" wire:model="remarks"></textarea>
            </div>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <script>
        window.addEventListener('close-modal', event => {
        $('#remarkModal').modal('hide')
        })
    </script>
</div>
<?php /**PATH C:\Users\romel\Desktop\alergiocurehms\resources\views/livewire/bm/request-list.blade.php ENDPATH**/ ?>