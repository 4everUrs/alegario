<div>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 font-weight-bold">
            <?php echo e(__('Accounts Recievable')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Recievables</h5>
            <table class="table datatable">
                <thead>
                    <th class="text-center align-middle">ID</th>
                    <th class="text-center align-middle">Type</th>
                    <th class="text-center align-middle">Amount</th>
                    <th class="text-center align-middle">Status</th>
                    <th class="text-center align-middle">Action</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $recievables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recievable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center align-middle"><?php echo e($recievable->id); ?></td>
                            <td class="text-center align-middle"><?php echo e($recievable->type); ?></td>
                            <td class="text-center align-middle"><?php echo '₱ ' . number_format($recievable->amount, 2); ?></td>
                            <td class="text-center align-middle"><?php echo e($recievable->status); ?></td>
                            <td class="text-center align-middle">
                                <button wire:click="pay_now(<?php echo e($recievable->id); ?>)" class="btn btn-primary btn-sm">Pay Now</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breeze-modal','data' => ['id' => 'payNowModal','model' => 'payNow','wire:ignore.self' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breeze-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'payNowModal','model' => 'payNow','wire:ignore.self' => true]); ?>
         <?php $__env->slot('title', null, []); ?> Pay now <?php $__env->endSlot(); ?>
         <?php $__env->slot('body', null, []); ?> 
            <div class="form-group">
                <label>Amount</label>
                <input type="text" class="form-control" wire:model='amount'>
            </div>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


    <script>
        window.addEventListener('show-modal', event=>{
            $('#payNowModal').modal('show');
        })
        window.addEventListener('close-modal', event=>{
            $('#payNowModal').modal('hide');
        })
    </script>
</div>
<?php /**PATH C:\Users\romel\Desktop\alergiocurehms\resources\views/livewire/ar/accounts-recievable.blade.php ENDPATH**/ ?>