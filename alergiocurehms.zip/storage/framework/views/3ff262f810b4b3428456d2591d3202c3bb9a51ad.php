<div>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 font-weight-bold">
            <?php echo e(__('Request List')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Title</h5>
            <table class="table datatable">
                <thead>
                    <th class="text-center align-middle">No</th>
                    <th class="text-center align-middle">Department</th>
                    <th class="text-center align-middle">Amount</th>
                    <th class="text-center align-middle">Description</th>
                    <th class="text-center align-middle">Date Request</th>
                    <th class="text-center align-middle">Date Approved</th>
                    <th class="text-center align-middle">Status</th>
                    <th class="text-center align-middle">Action</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center align-middle"><?php echo e($request->id); ?></td>
                            <td class="text-center align-middle"><?php echo e($request->BudgetRequests->department); ?></td>
                            <td class="text-center align-middle"><?php echo '₱ ' . number_format($request->BudgetRequests->amount, 2); ?></td>
                            <td class="text-center align-middle"><?php echo e($request->BudgetRequests->description); ?></td>
                            <td class="text-center align-middle"><?php echo Carbon\Carbon::parse($request->created_at)->toFormattedDateString()?></td>
                            <?php if(!empty($request->aproved_date)): ?>
                                <td class="text-center align-middle"><?php echo Carbon\Carbon::parse($request->date_aproved)->toFormattedDateString()?></td>
                            <?php else: ?>
                                <td class="text-center align-middle">--/--/----</td>
                            <?php endif; ?>
                            <td class="text-center align-middle"><?php echo e($request->status); ?></td>
                            <td class="text-center align-middle">
                                <button class="btn btn-sm btn-primary">Disburse</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\romel\Desktop\alergiocurehms\resources\views/livewire/disbursement/disburse-requests.blade.php ENDPATH**/ ?>