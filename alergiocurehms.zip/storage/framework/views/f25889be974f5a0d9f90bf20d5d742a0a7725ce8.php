<div>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 font-weight-bold">
            <?php echo e(__('Chart of Accounts')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <button class="btn btn-sm btn-primary mb-3" data-bs-target="#newAccount" data-bs-toggle="modal">+ Add new account</button>
   <div class="card">
    <div class="card-body">
        <h5 class="card-title">Accounts</h5>
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li wire:ignore class="nav-item" role="presentation"> <button class="nav-link active" id="Assets-tab" data-bs-toggle="tab"
                    data-bs-target="#Assets" type="button" role="tab" aria-controls="Assets"
                    aria-selected="true">Assets</button></li>
            <li wire:ignore class="nav-item" role="presentation"> <button class="nav-link" id="Liabilities-tab" data-bs-toggle="tab"
                    data-bs-target="#Liabilities" type="button" role="tab" aria-controls="Liabilities" aria-selected="false"
                    tabindex="-1">Liabilities</button></li>
            <li wire:ignore class="nav-item" role="presentation"> <button class="nav-link" id="Equity-tab" data-bs-toggle="tab"
                    data-bs-target="#Equity" type="button" role="tab" aria-controls="Equity" aria-selected="false"
                    tabindex="-1">Equity</button></li>
            <li wire:ignore class="nav-item" role="presentation"> <button class="nav-link" id="Revenue-tab" data-bs-toggle="tab"
                    data-bs-target="#Revenue" type="button" role="tab" aria-controls="Revenue" aria-selected="false"
                    tabindex="-1">Revenue</button></li>
            <li wire:ignore class="nav-item" role="presentation"> <button class="nav-link" id="Expenses-tab" data-bs-toggle="tab"
                    data-bs-target="#Expenses" type="button" role="tab" aria-controls="Expenses" aria-selected="false"
                    tabindex="-1">Expenses</button></li>
        </ul>
        <div class="tab-content pt-2" id="myTabContent" >
            <div wire:ignore.self class="tab-pane fade show active" id="Assets" role="tabpanel" aria-labelledby="Assets-tab"> 
                <table class="table datatable table-sm">
                    <thead>
                        <th>Account No</th>
                        <th>Account Name</th>
                        <th>Account Type</th>
                        <th>Balance</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($asset->id); ?></td>
                                <td><?php echo e($asset->name); ?></td>
                                <td><?php echo e($asset->type); ?></td>
                                <td><?php echo '₱ ' . number_format($asset->balance, 2); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div wire:ignore.self class="tab-pane fade" id="Liabilities" role="tabpanel" aria-labelledby="Liabilities-tab"> 
                <table class="table datatable table-sm">
                    <thead>
                        <th>Account No</th>
                        <th>Account Name</th>
                        <th>Account Type</th>
                        <th>Balance</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $liabilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($liability->id); ?></td>
                            <td><?php echo e($liability->name); ?></td>
                            <td><?php echo e($liability->type); ?></td>
                            <td><?php echo '₱ ' . number_format($liability->balance, 2); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div wire:ignore.self class="tab-pane fade" id="Equity" role="tabpanel" aria-labelledby="Equity-tab"> 
                <table class="table datatable table-sm">
                    <thead>
                        <th>Account No</th>
                        <th>Account Name</th>
                        <th>Account Type</th>
                        <th>Balance</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $equities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($equity->id); ?></td>
                            <td><?php echo e($equity->name); ?></td>
                            <td><?php echo e($equity->type); ?></td>
                            <td><?php echo '₱ ' . number_format($equity->balance, 2); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div wire:ignore.self class="tab-pane fade" id="Expenses" role="tabpanel" aria-labelledby="Equity-tab"> 
                <table class="table datatable table-sm">
                    <thead>
                        <th>Account No</th>
                        <th>Account Name</th>
                        <th>Account Type</th>
                        <th>Balance</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($expenses->id); ?></td>
                            <td><?php echo e($expenses->name); ?></td>
                            <td><?php echo e($expenses->type); ?></td>
                            <td><?php echo '₱ ' . number_format($expenses->balance, 2); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div wire:ignore.self class="tab-pane fade" id="Revenue" role="tabpanel" aria-labelledby="Equity-tab"> 
                <table class="table datatable table-sm">
                    <thead>
                        <th>Account No</th>
                        <th>Account Name</th>
                        <th>Account Type</th>
                        <th>Balance</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $revenues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revenue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($revenue->id); ?></td>
                            <td><?php echo e($revenue->name); ?></td>
                            <td><?php echo e($revenue->type); ?></td>
                            <td><?php echo '₱ ' . number_format($revenue->balance, 2); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breeze-modal','data' => ['id' => 'newAccount','model' => 'newAccount','wire:ignore.self' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breeze-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'newAccount','model' => 'newAccount','wire:ignore.self' => true]); ?>
     <?php $__env->slot('title', null, []); ?> 
        add new account
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('body', null, []); ?> 
        <div class="form-group">
            <label>Account Type</label>
            <select class="form-select" wire:model="type">
                <option value="">Choose..</option>
                <option value="Asset">Assets</option>
                <option value="Liabilities">Liabilities</option>
                <option value="Revenue">Revenue</option>
                <option value="Equity">Equity</option>
                <option value="Expenses">Expenses</option>
            </select>
            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label>Account Name</label>
            <input type="text" class="form-control" wire:model="name">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<script>
    window.addEventListener('close-modal-account', event => {
    $('#newAccount').modal('hide')
    })
</script>
</div>
<?php /**PATH C:\Users\romel\Desktop\alergiocurehms\resources\views/livewire/general/chart-of-accounts.blade.php ENDPATH**/ ?>