<div>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 font-weight-bold">
            <?php echo e(__('History')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Histories</h5>
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation"> <button class="nav-link active" id="budget-tab" data-bs-toggle="tab"
                        data-bs-target="#budget" type="button" role="tab" aria-controls="budget"
                        aria-selected="true">Budget</button></li>
                <li class="nav-item" role="presentation"> <button class="nav-link" id="Requests-tab" data-bs-toggle="tab"
                        data-bs-target="#Requests" type="button" role="tab" aria-controls="Requests" aria-selected="false"
                        tabindex="-1">Requests</button></li>
                
            </ul>
            <div class="tab-content pt-2" id="myTabContent">
                <div class="tab-pane fade active show" id="budget" role="tabpanel" aria-labelledby="budget-tab">
                    <table class="table table-bordered table-responsive">
                            <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($history->year); ?></td>
                                    <td style="width: 50px " class="text-center"><a data-bs-toggle="collapse" href="#collapseExample<?php echo e($index); ?>"
                                            class="bi bi-plus-square-fill"></a></td>
                                </tr>
                           

                                <tr>
                                    <td class="collapse" id="collapseExample<?php echo e($index); ?>" colspan="2">
                                        <div class="card card-body">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <th class="text-center" colspan="2"><?php echo e($history->year); ?></th>
                                                    
                                                </thead>
                                                <tr>
                                                    <td class="text-center" colspan="2">Encoded By: <?php echo e($history->encoded_by); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Operating</td>
                                                    <td style="width: 50%"><?php echo '₱ ' . number_format($history->operating, 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>General</td>
                                                    <td style="width: 50%"><?php echo '₱ ' . number_format($history->general, 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Maintenance</td>
                                                    <td style="width: 50%"><?php echo '₱ ' . number_format($history->maintenance, 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Improvisation</td>
                                                    <td style="width: 50%"><?php echo '₱ ' . number_format($history->improvisation, 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Total</td>
                                                    <td style="width: 50%"><?php echo '₱ ' . number_format($history->amount, 2); ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    
                </div>
                <div class="tab-pane fade" id="Requests" role="tabpanel" aria-labelledby="Requests-tab"> Nesciunt totam et.
                    Consequuntur magnam aliquid eos nulla dolor iure eos quia. Accusantium distinctio omnis et atque fugiat.
                    Itaque doloremque aliquid sint quasi quia distinctio similique. Voluptate nihil recusandae mollitia
                    dolores. Ut laboriosam voluptatum dicta.</div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\romel\Desktop\alergiocurehms\resources\views/livewire/bm/history.blade.php ENDPATH**/ ?>