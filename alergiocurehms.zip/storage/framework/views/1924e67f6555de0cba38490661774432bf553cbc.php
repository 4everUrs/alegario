<div>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 font-weight-bold">
            <?php echo e(__('Collections')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <button class="btn btn-sm btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#invoicemodal">+ Create Invoice</button>
    <div class="card" wire:ignore.self>
        <div class="card-body">
            <h5 class="card-title">Collections</h5>
            <table class="table datatable table-sm">
                <thead>
                    <th>Invoice No</th>
                    <th>Reciepient</th>
                    <th>Status</th>
                    <th></th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($collection->id); ?></td>
                            <td><?php echo e($collection->reciepient); ?></td>
                            <td><?php echo e($collection->status); ?></td>
                            <td style="width: 50px " class="text-center"><a  wire:click="loadData(<?php echo e($collection->id); ?>)" data-bs-toggle="collapse" href="#collapseExample<?php echo e($index); ?>"
                                    class="bi bi-plus-square-fill"></a></td>
                        </tr>
                        <tr>
                            <td class="collapse" id="collapseExample<?php echo e($index); ?>" colspan="4">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="p-3">
                                            <div class="action-buttons">
                                                <a class="btn btn-outline-success float-end" href="#" data-title="Print">
                                                    <i class="bi bi-printer-fill"></i>
                                                    Print
                                                </a>
                                                <a class="btn btn-outline-danger" href="#" data-title="PDF">
                                                    <i class="bi bi-file-earmark-pdf-fill"></i>
                                                    Export
                                                </a>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <h5 class="card-title">Invoice No: <b class="text-danger"><?php echo e($collection->id); ?></b></h5>
                                                <h5>To: <b><?php echo e($collection->reciepient); ?></b></h5>
                                                <h5> <i class="bi bi-map-fill"></i> <?php echo e($collection->address); ?></h5>
                                                <h5><i class="bi bi-telephone-fill"></i> <?php echo e($collection->phone); ?></h5>
                                            </div>
                                            <div class="col-md">
                                                <h5 class="card-title">Date Issued: <b class="text-danger"><?php echo Carbon\Carbon::parse($collection->created_at)->toFormattedDateString()?></b></h5>
                                                <h5>Institution: <b>Alegario Cure Medical</b></h5>
                                                <h5>Practioner: <b><?php echo e($collection->Practitioner->name); ?></b></h5>
                                                <h5>License No: <b><?php echo e($collection->Practitioner->license); ?></b></h5>
                                                <h5>Address: <b><?php echo e($collection->Practitioner->address); ?></b></h5>
                                                <h5>Phone: <b><?php echo e($collection->Practitioner->phone); ?></b></h5>
                                            </div>
                                        </div>
                                        <?php if($cash_collection == 'cash'): ?>
                                            <div class="" id="cash-fields">
                                                <table class="table table-bordered">
                                                    <thead class="bg-info">
                                                        <th style="width: 20%" class="text-center align-middle">Payment Method</th>
                                                        <th class="text-center align-middle">Total Cost</th>
                                                        <th class="text-center align-middle">Status</th>
                                                    </thead>
                                                    <tbody>
                                                        <?php if(!empty($cash_collection)): ?>
                                                        <tr>
                                                            <td class="text-center align-middle"><?php echo e($cash_collection); ?></td>
                                                            <td class="text-center align-middle"><?php echo '₱ ' . number_format($grandTotal, 2); ?></td>
                                                            <td class="text-center align-middle"><span class="badge bg-success text-dark">Paid</span></td>
                                                        </tr>
                                                        <?php else: ?>
                                            
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php endif; ?>
                                        <?php if($cash_collection == 'installment'): ?>
                                            <div class="">
                                                <table class="table">
                                                    <thead class="bg-info">
                                                        <th>Account No</th>
                                                        <th>Total Amount</th>
                                                        <th>Payment Type</th>
                                                        <th>Downpayment</th>
                                                        <th>Balance</th>
                                                        <th>Monthly Due</th>
                                                        <th>Paid Amount</th>
                                                        <th>Interest</th>
                                                        <th>Term</th>
                                                        <th>Status</th>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td><?php echo e($installment_data->id); ?></td>
                                                            <td><?php echo '₱ ' . number_format($installment_data->amount, 2); ?></td>
                                                            <td>Installment</td>
                                                            <td><?php echo '₱ ' . number_format($installment_data->downpayment, 2); ?></td>
                                                            <td><?php echo '₱ ' . number_format($installment_data->balance, 2); ?></td>
                                                            <td><?php echo '₱ ' . number_format($installment_data->monthly_due, 2); ?></td>
                                                            <td><?php echo '₱ ' . number_format($installment_data->paid_amount, 2); ?></td>
                                                            <td><?php echo e($installment_data->interest); ?> %</td>
                                                            <td><?php echo e($installment_data->paid); ?>/<?php echo e($installment_data->terms); ?></td>
                                                            <?php if($installment_data->balance == 0): ?>
                                                                <td><span class="badge bg-success text-dark">Paid</span></td>
                                                            <?php else: ?>
                                                                <td><span class="badge bg-warning text-dark">Unpaid</span></td>
                                                            <?php endif; ?>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php endif; ?>
                                        <table class="table table-bordered">
                                            <thead class="bg-info">
                                                <th class="text-center">No</th>
                                                <th class="text-center">Particulars</th>
                                                <th class="text-center">Qty</th>
                                                <th class="text-center">Cost</th>
                                                <th class="text-center">Total</th>
                                            </thead>
                                            <tbody>
                                                <?php if(!empty($particulars)): ?>
                                                    <?php $__currentLoopData = $particulars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $particular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="text-center"><?php echo e($index+1); ?></td>
                                                        <td class="text-center"><?php echo e($particular->particular); ?></td>
                                                        <td class="text-center"><?php echo e($particular->quantity); ?></td>
                                                        <td class="text-center"><?php echo '₱ ' . number_format($particular->cost, 2); ?></td>
                                                        <td><?php echo '₱ ' . number_format($particular->total_cost, 2); ?></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="5"></td>
                                                    </tr>
                                                <?php endif; ?>
                                                <tr class="bg-secondary">
                                                    <td colspan="5"></td>
                                                </tr>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td colspan="3"><b>Summary</b></td>
                                                    <td class="text-end">Sub-Total:</td>
                                                    <td><?php echo '₱ ' . number_format($subTotal, 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="3"></td>
                                                    <td class="text-end">Tax:</td>
                                                    <td><?php echo '₱ ' . number_format($tax, 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="3"></td>
                                                    <td class="text-end">Discount:</td>
                                                    <td><?php echo '₱ ' . number_format($collection->discount, 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="3"></td>
                                                    <td class="text-end">Grand Total:</td>
                                                    <td><?php echo '₱ ' . number_format($grandTotal, 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5">
                                                        <button class="btn btn-primary float-end">Pay now</button>
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breeze-modal','data' => ['id' => 'invoicemodal','model' => 'createInvoice','class' => 'modal-lg','wire:ignore.self' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breeze-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'invoicemodal','model' => 'createInvoice','class' => 'modal-lg','wire:ignore.self' => true]); ?>
         <?php $__env->slot('title', null, []); ?> 
            Create Invoice
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('body', null, []); ?> 
            <small><b class="text-danger">*</b> Field is required!</small>
            <div class="form-group">
                <label>Reciepient <b class="text-danger">*</b></label>
                <input wire:model="reciepient" type="text" class="form-control">
                <?php $__errorArgs = ['reciepient'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label>Address <b class="text-danger">*</b></label>
                <input wire:model="address" type="text" class="form-control">
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label>Phone <b class="text-danger">*</b></label>
                <input wire:model="phone" type="text" class="form-control">
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label>Practitioner <b class="text-danger">*</b></label>
                <select class="form-select" wire:model="practitioner">
                    <option value="">Choose..</option>
                    <?php $__currentLoopData = $practitioners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $practitioner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($practitioner->id); ?>"><?php echo e($practitioner->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['practitioner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <div class="row">
                        <div class="col">
                            <label>Particulars <b class="text-danger">*</b></label>
                            <input wire:model="particular" type="text" class="form-control">
                            <?php $__errorArgs = ['items'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-2">
                            <label>Quantity <b class="text-danger">*</b></label>
                            <input wire:model="quantity" type="text" class="form-control">
                            <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col">
                            <label>Amount <b class="text-danger">*</b></label>
                            <input wire:model="amount" type="text" class="form-control">
                            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-2">
                            <label></label>
                            <button class="btn btn-sm btn-danger form-control" wire:click="insertItem">Add Item</button>
                        </div>
                    </div>
                </div>
                <label>Payment Method <b class="text-danger">*</b></label>
                <select class="form-select" wire:model="payment_method">
                    <option value="">Choose..</option>
                    <option value="cash">Cash</option>
                    <option value="installment">Installment</option>
                    <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </select>
                <label>Discount (Optional)</label>
                    <div class="input-group mb-3">
                        <span class="input-group-text">₱</span>
                        <input type="number" class="form-control" wire:model="discount" placeholder="Optional">
                        <span class="input-group-text">.00</span>
                        
                    </div>
                <div class="form-group d-none" id="installmentFields">
                    <div class="row">
                        <div class="col">
                            <label>Terms</label>
                            <div class="input-group mb-3"> <input type="text" class="form-control" wire:model="terms">
                                <span class="input-group-text">month(s)</span>
                            </div>
                        </div>
                        <div class="col">
                            <label>Downpayment</label>
                            <div class="input-group mb-3"> 
                                <span class="input-group-text">$</span> 
                                <input type="text" class="form-control" wire:model="downpayment">
                                <span class="input-group-text">.00</span>
                            </div>
                        </div>
                        <div class="col">
                            <label>Interest Rate</label>
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" wire:model="interest">
                                <span class="input-group-text">%</span>
                            </div>
                        </div>
                    </div>
                </div>
                <table class="table mt-4">
                    <thead class="bg-info">
                        <th class="text-center">No</th>
                        <th class="text-center">Particulars</th>
                        <th class="text-center">Qty</th>
                        <th class="text-center">Cost</th>
                        <th class="text-center">Amount</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index  => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($index+1); ?></td>
                                <td class="text-center"><?php echo e($item['particular']); ?></td>
                                <td class="text-center"><?php echo e($item['quantity']); ?></td>
                                <td class="text-center"><?php echo e($item['amount']); ?></td>
                                <td class="text-center"><?php echo e($item['amount']*$item['quantity']); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr class="bg-secondary">
                            <td colspan="5"></td>
                        </tr>
                        <tr>
                            <td colspan="3">Summary</td>
                            <td>Sub-Total:</td>
                            <td><?php echo '₱ ' . number_format($subTotal, 2); ?></td>
                        </tr>
                        <tr>
                            <td colspan="3"></td>
                            <td>Tax:</td>
                            <td><?php echo '₱ ' . number_format($tax, 2); ?></td>
                        </tr>
                        <tr>
                            <td colspan="3"></td>
                            <td>Discount:</td>
                            <td><?php echo '₱ ' . number_format($discount, 2); ?></td>
                        </tr>
                        <tr>
                            <td colspan="3"></td>
                            <td><b>Grand Total:</b></td>
                            <td><b><?php echo '₱ ' . number_format($grandTotal, 2); ?></b></td>
                        </tr>

                    </tfoot>
                </table>

            </div>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <script>
       window.addEventListener('show-fields', event => {
            var x = document.getElementById('installmentFields');
            x.classList.remove('d-none');
        })
       window.addEventListener('close-modal', event => {
            $('#invoicemodal').modal('hide');
        })
       window.addEventListener('cash-fields', event => {
            var x = document.getElementById('cash-fields');
            x.classList.remove('d-none');
        })
    </script>
</div>
<?php /**PATH C:\Users\romel\Desktop\alergiocurehms\resources\views/livewire/collections/collections.blade.php ENDPATH**/ ?>